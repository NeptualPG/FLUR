# Design System Specification

## 1. Overview & Creative North Star: "The Ethereal Professional"
This design system moves away from the rigid, "boxed-in" layout of traditional SaaS and fintech platforms. The Creative North Star is **The Ethereal Professional**—a visual philosophy that balances the unwavering security of Petrol Blue with the breathing room of an editorial lookbook.

The system breaks the "template" look through **Intentional Asymmetry**. Instead of perfectly centered grids, we use generous, unequal whitespace and overlapping elements to create a sense of movement. We avoid structural lines in favor of "Tonal Islands"—grouping content through subtle shifts in surface color rather than borders. This creates a high-end, bespoke feel where the UI feels like it was "composed" rather than "assembled."

---

## 2. Colors & Surface Architecture
The palette is rooted in deep, authoritative Petrol Blue and energized by Mint Green. However, the secret to the high-end feel lies in the **Neutrals**.

### The "No-Line" Rule
**Explicit Instruction:** Traditional 1px solid borders are prohibited for sectioning. To separate a header from a hero, or a sidebar from a main feed, use background color shifts only.
*   **Surface:** `#f8f9fa` (The base canvas)
*   **Surface-Container-Low:** `#f3f4f5` (Subtle grouping)
*   **Surface-Container-High:** `#e7e8e9` (Active/Prominent areas)

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. 
*   **Layer 1 (Canvas):** `surface`
*   **Layer 2 (Section):** `surface-container-low`
*   **Layer 3 (Component/Card):** `surface-container-lowest` (#ffffff)
This "reverse nesting" (putting a white card on a light grey section) creates a soft, natural lift that communicates hierarchy without visual noise.

### The Glass & Gradient Rule
To prevent the design from feeling flat, use **Glassmorphism** for floating elements (Navigation bars, Tooltips, Modals).
*   **Recipe:** `surface` at 80% opacity + `backdrop-blur: 20px`.
*   **Signature Textures:** Apply a linear gradient (45°) from `primary` (#004655) to `primary_container` (#005f73) for Hero CTAs to provide depth and "soul."

---

## 3. Typography: The Editorial Scale
We pair the geometric confidence of **Space Grotesk** with the functional clarity of **Inter**.

*   **The Power Play (Display-LG/MD):** Use `spaceGrotesk` for headlines. Tighten letter-spacing by -2% for a high-fashion, "tight" editorial look.
*   **The Narrative (Body-LG/MD):** Use `inter`. Use a generous line-height (1.6) to ensure the "Professional" aspect feels approachable and modern.
*   **Micro-Context (Label-SM):** All labels must be in `inter`, Uppercase, with +5% letter-spacing to act as "architectural markers" on the page.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are too "cheap" for this system. We use **Ambient Depth**.

*   **The Layering Principle:** Stack `surface-container` tiers. A `surface-container-lowest` card sitting on a `surface-container-low` background is the primary way to show elevation.
*   **Ambient Shadows:** If a shadow is required for a floating Modal or Popover, use:
    *   `box-shadow: 0 24px 48px -12px rgba(0, 70, 85, 0.08);` (A Petrol-tinted shadow feels more natural than black).
*   **The "Ghost Border" Fallback:** If a border is required for accessibility, use `outline_variant` at **15% opacity**. Never use a 100% opaque border.

---

## 5. Components

### Buttons: The "Soft-Touch" Action
*   **Primary:** Gradient of `primary` to `primary_container`. `md` (0.375rem) roundedness. 
*   **Secondary:** `secondary_fixed_dim` text on a `surface-container-high` background. No border.
*   **Interaction:** On hover, buttons should subtly expand (scale: 1.02) with a `300ms ease-out` transition.

### Input Fields: The "Quiet" Input
*   **Style:** Minimalist. Only a bottom-border using `outline_variant` at 40%. 
*   **Focus State:** The bottom border transitions to `secondary` (#2b6958) and the background shifts to `surface-container-lowest`.

### Cards & Lists: The "No-Divider" List
*   **Constraint:** Forbid the use of divider lines.
*   **Implementation:** Separate list items using `spacing-3` (1rem) and use a hover state that changes the background to `surface-container-low`.
*   **Cards:** Use `xl` (0.75rem) roundedness for large containers to soften the "Professional" Petrol Blue and make it feel "Fresh."

### Chips: The "Micro-Fresh" Detail
*   **Selection Chips:** Use `secondary_container` with `on_secondary_container` text. These act as the "Mint Green" pops of color that highlight user choices.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical margins (e.g., 8.5rem left margin, 4rem right margin) for landing pages to create an editorial feel.
*   **Do** allow product photography to overlap into different background color sections.
*   **Do** use `primary_fixed_dim` for large icon backgrounds to keep the "Professional" tone light and airy.

### Don't:
*   **Don't** use pure black (#000000) for text. Always use `on_surface` (#191c1d).
*   **Don't** use 90-degree sharp corners. This system relies on `md` and `xl` roundedness to feel "Sleek" rather than "Brutalist."
*   **Don't** use standard "Drop Shadows." If it doesn't look like it's glowing subtly from ambient light, it's too heavy.
*   **Don't** use more than one Mint Green (`secondary`) element per viewport; it is a highlight, not a primary fill.